import React, { useState } from 'react';
import { Text, View, StyleSheet, Image } from 'react-native';

const styles = StyleSheet.create({
  container: {
    alignItems: 'center',
    margin: 25,
    padding: 8,
  },
  textIntro: {
    fontSize: 18,
    color: '#f44336',
  },
  textBasic: {
    margin: 25,
    fontSize: 14,
    color: '#adaaaa',
  },
  textSignature: {
    fontSize: 16,
    fontWeight: 'bold',
  },
  logoImageLayout: {
    width: 100,
    height: 100,
    margin: 20,
  },
  circleImageLayout: {
    width: 100,
    height: 100,
    borderRadius: 200 / 2,
    marginTop: 100,
  },
});

const AppGreeting = (props) => {
  return (
    <View style={styles.container}>
      <Image
        source={require('./assets/kirbis.png')}
        style={styles.logoImageLayout}
      />
      <Text style={styles.textIntro}>
        Hello World from Group {props.groupNr}{'\n'}
        Member: {props.name} {props.surname}
      </Text>
      <Text style={styles.textBasic}>
        This is my {props.name} {props.surname} first React Native application! {'\n'}
        {'\n'}
        Nice to see you here!
      </Text>
      <Image
        source={require('./assets/autumn.jpg')}
        style={styles.circleImageLayout}
      />
      <Text style={styles.textSignature}>
        {props.name} {props.surname}
      </Text>
    </View>
  );
};
export default function GroupMembers() {
  return (
    <View>
      <AppGreeting name="Ieva" surname="Lauga" groupNr="nG02" />
    </View>
  );
}
